function f = EV_getData

filename='C:\Users\kalpeshs001\Documents\HESS\EV HESS.xlsx';

Data = xlsread(filename,'Random Sample Generator','I20:T39')

end
