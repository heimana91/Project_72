Authors: Heimana Palmer and Sanath Vettivel
The University of Auckland

-----------------------------------------------------------------------------------------------------
To get results working.
-----------------------------------------------------------------------------------------------------

Each of the three decision algorithms has a file called Results.csv located in 
blokide_evstation\Generated\Run inside the program file.


To obtain the results there are two options:

Options 1:
Copy the Demand, Pgrid, Pbc, Pbd columns and paste them with the corresponding column 
in templateFinal.xlsx. 

E.g.) Results from the artificial neural network (ResultsANN.csv) would be copied and pasted into 
templateFinal.xlsx in the correct sheet.


Options 2: 
Multiply the Pgrid * Price column in a free column. This will give the 
price with the existing ESS
 and 
Demand * Price column will give the cost without an ESS.


-----------------------------------------------------------------------------------------------------
Future Work
-----------------------------------------------------------------------------------------------------
  
-Combination of decision algorithms. This hybrid algorithm would specifically use the artificial neural network and bollinger bands 

-Replacing the first basic function block called "sifb_bfb_inputs.fb" into a service interface 
function block for a real live time analysis. i.e. online communication 

-Improve the energy demand forcast.
Include renewable energy sources in the system