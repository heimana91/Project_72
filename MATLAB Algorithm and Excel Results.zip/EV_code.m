tic

%EV_getData;                  %Read data from excel file 'C:\Users\kalpeshs001\Documents\HESS\Work on EV\EV HESS.xlsx'

filename='H:\Desktop\New Code\kalpesh_matlab\EV HESS.xlsx';

Data = xlsread(filename,'Random Sample Generator','I20:T39');
Data_Price= xlsread(filename,'Random Sample Generator','I20:T39');

Cn_Temp=Data(:,1);           %Battery capacity for each vehicle
Cn=Cn_Temp;                  %Battery capacity for each vehicle

SOCi_Temp=Data(:,2);         %Initial SOC for each vehicle
SOCi=SOCi_Temp;              %Initial SOC for each vehicle

SOCf_Temp=Data(:,3);         %Final SOC for each vehicle
SOCf=SOCf_Temp;              %Final SOC for each vehicle

X_Temp=Data(:,4);             %Check for vehicle availability (Binary logic)
X=X_Temp;                    %Check for vehicle availability (Binary logic)

Pi_Temp=Data(:,5);           %Initial capacity of each vehicle
Pi=Pi_Temp;                  %Initial capacity of each vehicle

Pf_Temp=Data(:,6);           %Final capacity of each vehicle
Pf=Pf_Temp;                  %Final capacity of each vehicle

Tc_Temp=Data(:,9);           %Charging time for each vehicle
Tc=Tc_Temp;                  %Charging time for each vehicle

P1_Temp=Data(:,10);          %Charging power per min. for each vehicle till 80% SOC
P1=P1_Temp;                  %Charging power per min. for each vehicle till 80% SOC

P2_Temp=Data(:,11);          %Charging power per min. for each vehicle till 100% SOC
P2=P2_Temp;                 %Charging power per min. for each vehicle till 100% SOC


m = zeros(20,1);
l = zeros(20,1);
Preq = zeros(20,1441);
P = zeros(1,1441);
Pc = zeros(20,1);
Pt = zeros(20,1);
SOCt = zeros(20,1441);
SOCtemp = zeros(20,1441);
SOCtemp(:,1) = SOCi;

day='temp';


 Cb = 620 ;       % Capacity of battery kWh
 SOCb = zeros(1441,1);
 SOCb(1,1) = 90;
 Pg=zeros(1441,1);
 
 Pbd = zeros(1441,1);
 Pbc = zeros(1441,1);
 PbdMax = 150; %Discharging rate of ESS (kWh)
 PbcNom=200; %Charging rate of ESS (kWh)
 Peak= 130; %Peak energy from grid (kWh)

%Loop through one week
for R = 1:7

  if R==1
   day='Monday';   
  end
  if R==2
   day='Tuesday';   
  end
  if R==3
   day='Wednesday';   
  end
  if R==4
   day='Thursday';   
  end
  if R==5
    day='Friday';  
  end
  if R==6
    day='Saturday';  
  end
  if R==7
    day='Sunday';  
  end
  
    

%Loop through every minute of the day
for i = 2:1441             % 24 * 60 = 1440 min. of one day. 
    
 j=i;
      
   %Twenty vehicles 
    for n = 1:20
        
        %Checking if SoC of EV is below 80%
        if Pt(n,1) < ( 0.8 * Cn(n,1) )
            Pc(n,1)=P1(n,1);
        end
      
        %Checking if SoC of EV is above 80%
        if Pt(n,1) > ( 0.8 * Cn(n,1) )
            Pc(n,1)=P2(n,1);
        end
        
        %Checking if EV at n charging port and calculating the SoC of this
        %n EV
        if ( X(n,1) == 1 )
        SOCt(n,i) = ( SOCtemp(n,i-1) + ( Pc(n,1) * 100 /( Cn(n,1) * 60 ) ) ) ; %Calculating SoC of each EV
        Pt(n,1) = Cn(n,1) * SOCt(n,i)/100; 
        SOCtemp(n,i)= SOCt(n,i);
        Preq(n,i)=Pc(n,1);
        m(n,1)=0;
        l(n,1)=1;
        end
   
        %Check if SoC of EV is met with final SoC. If so, flags set.
       if ( ( Pt(n,1) > Pf(n,1) )) && ( SOCt(n,i) > SOCf(n,1) ) 
       %   Cn(n,1) = 0 ;
       %   SOCi(n,1) = 0 ;         
       %   Pi(n,1) = 0 ;            
       %   Tc(n,1) = 0 ;            
          P1(n,1) = 0 ;             
          P2(n,1) = 0 ; 
          X(n,1) = 0;
          m(n,1) = 1;
          l(n,1)= 0;
       end
          
      
    end
    
    
    %  Preq(i) = sum(Pt);         %Calculate required power at each minute
    
    
   %Every 30 minutes, or if there is an EV that has finished charging,
   %upadte charging port.
if (mod(i,30)==0) ||(sum(m)>0)
      
      filename='H:\Desktop\New Code\kalpesh_matlab\EV HESS.xlsx';
      Data = xlsread(filename,'Random Sample Generator','I20:T39');
      Opened=i
      
     X_Temp=Data(:,4);             %Check for vehicle availability (Binary logic)
     
      
        
   for n = 1:20
      if ( l(n,1) == 0 &&  ( X_Temp(n,1) == 1 ) )%&& ( X(n,1) == 0 ) )  %Updates particular EV
                 
Cn_Temp=Data(:,1);                     %Battery capacity for each vehicle
Cn(n,1)=Cn_Temp(n,1);                  %Battery capacity for each vehicle

SOCi_Temp=Data(:,2);                   %Initial SOC for each vehicle
SOCi(n,1)=SOCi_Temp(n,1);              %Initial SOC for each vehicle
SOCtemp(n,i) = SOCi(n,1);

SOCf_Temp=Data(:,3);                   %Final SOC for each vehicle
SOCf(n,1)=SOCf_Temp(n,1);              %Final SOC for each vehicle


Pi_Temp=Data(:,5);                     %Initial capacity of each vehicle
Pi(n,1)=Pi_Temp(n,1);                  %Initial capacity of each vehicle

Pf_Temp=Data(:,6);                     %Final capacity of each vehicle
Pf(n,1)=Pf_Temp(n,1);                  %Final capacity of each vehicle

Tc_Temp=Data(:,9);                     %Charging time for each vehicle
Tc(n,1)=Tc_Temp(n,1);                  %Charging time for each vehicle

P1_Temp=Data(:,10);                    %Charging power per min. for each vehicle till 80% SOC
P1(n,1)=P1_Temp(n,1);                  %Charging power per min. for each vehicle till 80% SOC

P2_Temp=Data(:,11);                    %Charging power per min. for each vehicle till 100% SOC
P2(n,1)=P2_Temp(n,1);                  %Charging power per min. for each vehicle till 100% SOC
                 
X(n,1)=X_Temp(n,1);                    %vehicle availability (Binary logic)

m(n,1)=0;
                 
            
       end
    end 
end

 
 
 %Sum all energy required at charging station
 P = sum(Preq);
 

 %Check first minute of every day and set SoC accordingly
if strcmp(day,'Monday')==1 %Making sure SoC doesn't reset every day
    SOCb(1)=90;
else
    SOCb(1)=SOCb(1441); %Grab last array value of SoC (which is SoC value of last minute of previous day)
end

%NOTE: Commenting of ESS Mode of Operation is for Monday only. Other days follow same fashion (but different times for mode of operation). 


if strcmp(day,'Monday')==1
    
    SOCb(i)=SOCb(i-1); %Start SoC of ESS with previous value
    
    
    if ( (j>(599) && j<(721)) || (j>(1229) && j<(1351)) )    % Peak time
        
        Pbc(i) = 0; % No Charging
        
       if SOCb(i-1) > 25 %If SoC above lower limit
                    
        if PbdMax > P(i) %Check if ESS can solely charge EV
            Pbd(i) = P(i); %Use ESS to charge EV
        else 
            Pbd(i) = PbdMax; %Else ESS gives max energy and grid provides the rest of the required energy.
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60)); %Update SoC of ESS
        
      
       
       elseif SOCb(i-1) < 25 %If SoC is below lower limit
           Pg(i) = P(i); %Set energy grid supply as energy demanded at station (since ESS is unfit for charging)
           SOCb(i) = SOCb(i-1); %Update SoC with previous SoC
           Pbd(i) = 0; %ESS is discharging 0 kWh

       end
       
    end

    if ( (j<(600) && j>(540)) || (j<(1081) && j>(720)) || (j<(31) || j>(1350)) || (j > (1139) && j < (1230)) )    % OFF Peak time
        
        Pbc(i)=0; %Set charging of ESS as 0 kWh
                
      if SOCb(i-1) > 25 %Check if ESS SoC above lower limit
        
        if P(i) > Peak %Check if energy demanded at charging station is above peak energy supply of grid (130 kWh)
            
        if ( PbdMax > ( P(i) - Peak ) ) %Check if max ESS discharge (150 kWh) is greater than difference of (energy demanded - 130 kWh) 
            Pbd(i) = P(i) - Peak ; %Set discharge of ESS as difference between energy demanded and peak grid energy suplpy (130 kWh)
            Pg(i) = Peak; %Grid energy supply set as peak grid energy (130 kWh)
        else 
            Pbd(i) = PbdMax; %Set ESS discharge as 150 kWh
            Pg(i) = P(i) - PbdMax; %Set grid energy as difference of (energy demanded - 150 kWh)
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60)); %Update SoC
        
        else
          Pg(i) = P(i); %Set grid energy supply as EV energy demand
          SOCb(i) = SOCb(i-1); %Update SoC with previous SoC
        end
       
      elseif SOCb(i-1) < 25 %Else if SoC is below lower limit
           Pg(i) = P(i); %Set grid energy supply to energy demanded 
           SOCb(i) = SOCb(i-1); %Update SoC with previous SoC
           Pbd(i) = 0; %Set discharg of ESS as 0 kWh (since grid is sole supplier of energy)
            
    
     end
    end
    
        
        
    if ( ((j<(541)&&j>(1*30)) || (j<(38*30)&&j>(36*30))) )    % OFF Peak time for charging EV station ESS
        
        Pbd(i)=0; %Set discharge of ESS as 0 kWh
        
        if SOCb(i-1)<95 %Check if SoC of ESS is below upper limit 
        
           Pbc(i)=PbcNom; %Set charging rate of ESS sa 200 kWh
           Pg(i) = P(i) + Pbc(i);  %Set energy from grid as energy demand + ESS charging energy (kWh)
        
           SOCb(i)=SOCb(i-1)+(Pbc(i)*100/(Cb*60)); %SoC calcualted
        else
            
           Pbc(i)=0; %Set ESS charging as 0 kWh
           Pg(i) = P(i); %Set energy from grid as energy demanded at charging station
           SOCb(i) = SOCb(i-1); %Update SoC with previous SoC
           
        end
    end  
end
            
            
if strcmp(day,'Tuesday')==1
    
     SOCb(i)=SOCb(i-1);
    
    if ( (j>(599) && j<(751)) || (j>(1260) && j<(1351)) )    % Peak time
        
        Pbc(i) = 0; % No Charging
        
       if SOCb(i-1) > 25
                    
        if PbdMax > P(i)
            Pbd(i) = P(i);
            Pg(i)= 0;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
       end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
       
       
       elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           Pbd(i) = 0;
           SOCb(i) = SOCb(i-1);

       end
       
    end
    
    if ( (j<(600) && j>(540)) || (j<(1081) && j>(750)) || j<(91) || j>(1350) )    % OFF Peak time
        
        Pbc(i)=0;
                
      if SOCb(i-1) > 25
        
        if P(i) > Peak
            
        if ( PbdMax > ( P(i) - Peak ) )
            Pbd(i) = P(i) - Peak ;
            Pg(i) = Peak;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
        else
          Pg(i) = P(i);
          SOCb(i) = SOCb(i-1);
          Pbd(i) = 0; 
        end
       
      elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0;

       end
    
     end

    
    
    if ( ((j<(541) && j>(90)) || (j<(1261) && j>(1080))) )    % OFF Peak time for charging batteries
        
        Pbd(i)=0;
        
        if SOCb(i-1)<90
        
           Pbc(i)=PbcNom;
           Pg(i) = P(i) + Pbc(i);    %PbcNom defined already
        
           SOCb(i)=SOCb(i-1)+(Pbc(i)*100/(Cb*60));
        else
            
           Pbc(i)=0;
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1); 
           
        end
    end  
end

    
    
if strcmp(day,'Wednesday')==1
    
     SOCb(i)=SOCb(i-1);
         
    if ( (j>(600) && j<(721)) || (j>(1229) && j<(1351)) )    % Peak time
        
        Pbc(i) = 0; % No Charging
        
       if SOCb(i-1) > 25
                    
        if PbdMax > P(i)
            Pbd(i) = P(i);
            Pg(i)= 0;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
       
       
       elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0; 

       end
       
    end

    if ( (j<(601) && j>(570)) || (j<(1051) && j>(720)) || j<(91) || j>(1350) )    % OFF Peak time
        
        Pbc(i)=0;
                
      if SOCb(i-1) > 25
        
        if P(i) > Peak
            
        if ( PbdMax > ( P(i) - Peak ) )
            Pbd(i) = P(i) - Peak ;
            Pg(i) = Peak;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
        else
          Pg(i) = P(i);
          SOCb(i) = SOCb(i-1); 
          Pbd(i) = 0; 
        end
       
      elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0; 

      end
     
    end
     
    
    if ( ((j<(571) && j>(90)) || (j<(1230) && j>(1050))) )    % OFF Peak time for charging batteries
        
        Pbd(i)=0;
        
        if SOCb(i-1)<90
        
           Pbc(i)=PbcNom;
           Pg(i) = P(i) + Pbc(i);    %PbcNom defined already
        
           SOCb(i)=SOCb(i-1)+(Pbc(i)*100/(Cb*60));
        else
            
           Pbc(i)=0;
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1); 
           
        end
    end  
end
 
 
if strcmp(day,'Thursday')==1    
    
     SOCb(i)=SOCb(i-1);
     
    if ( (j>(479) && j<(601)) || (j>(959) && j<(1051)) || (j>(1229) && j<(1351)) )    % Peak time
        
        Pbc(i) = 0; % No Charging
        
       if SOCb(i-1) > 25
                    
        if PbdMax > P(i)
            Pbd(i) = P(i);
            Pg(i)= 0;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
       
       
       elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0;

       end
       
    end
    
    if ( (j<(691) && j>(600)) || (j<(960) && j>(929)) || (j<(1230) && j>(1050)) || j<(91) || j>(1350) )    % OFF Peak time
        
        Pbc(i)=0;
                
      if SOCb(i-1) > 25
        
        if P(i) > Peak
            
        if ( PbdMax > ( P(i) - Peak ) )
            Pbd(i) = P(i) - Peak ;
            Pg(i) = Peak;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
        else
          Pg(i) = P(i);
          SOCb(i) = SOCb(i-1); 
          Pbd(i) = 0;
        end
       
      elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0;

       end
    
     end
  
    
     
    if ( ((j<(480) && j>(90)) || (j<(930) && j>(690))) )    % OFF Peak time for charging batteries
        
        Pbd(i)=0;
        
        if SOCb(i-1)<90
        
           Pbc(i)=PbcNom;
           Pg(i) = P(i) + Pbc(i);    %PbcNom defined already
        
           SOCb(i)=SOCb(i-1)+(Pbc(i)*100/(Cb*60));
        else
            
           Pbc(i)=0;
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1); 
           
        end
    end  
end
 
 
if strcmp(day,'Friday')==1  
    
     SOCb(i)=SOCb(i-1);
    
    if ( j>(1169) && j<(1351) )    % Peak time
        
        Pbc(i) = 0; % No Charging
        
       if SOCb(i-1) > 25
                    
        if PbdMax > P(i)
            Pbd(i) = P(i);
            Pg(i)= 0;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
       
       
       elseif SOCb(i-1) < 25
              Pg(i) = P(i);
              SOCb(i) = SOCb(i-1);
              Pbd(i) = 0;

       end
       
    end
    
    
    if ( (j<(1170) && j>(629)) || j<(91) || j>(1350) )    % OFF Peak time
        
        Pbc(i)=0;
                
      if SOCb(i-1) > 25
        
        if P(i) > Peak
            
        if ( PbdMax > ( P(i) - Peak ) )
            Pbd(i) = P(i) - Peak ;
            Pg(i) = Peak;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
        else
          Pg(i) = P(i);
          SOCb(i) = SOCb(i-1); 
          Pbd(i) = 0;
        end
       
      elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0; 

     end
    end
    
    
    if ( ((j<(630) && j>(90))) )    % OFF Peak time for charging batteries
        
        Pbd(i)=0;
        
        if SOCb(i-1)<90
        
           Pbc(i)=PbcNom;
           Pg(i) = P(i) + Pbc(i);    %PbcNom defined already
        
           SOCb(i)=SOCb(i-1)+(Pbc(i)*100/(Cb*60));
        else
            
           Pbc(i)=0;
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1); 
           
        end
    end  
end

 
if strcmp(day,'Saturday')==1
    
     SOCb(i)=SOCb(i-1);
    
    if ( (j>(599) && j<(751)) || (j>(1169) && j<(1321)) )    % Peak time
        
        Pbc(i) = 0; % No Charging
        
       if SOCb(i-1) > 25
                    
        if PbdMax > P(i)
            Pbd(i) = P(i);
            Pg(i)= 0;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
       
       
       elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0;

       end
       
    end
    
    if ( (j<(600) && j>(509)) || j<(121) || (j>(750) && j<1170) || (j>1320) )    % OFF Peak time
        
        Pbc(i)=0;
                
      if SOCb(i-1) > 25
        
        if P(i) > Peak
            
        if ( PbdMax > ( P(i) - Peak ) )
            Pbd(i) = P(i) - Peak ;
            Pg(i) = Peak;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
        else
          Pg(i) = P(i);
          SOCb(i) = SOCb(i-1); 
        end
        
      
      
      elseif SOCb(i-1) < 25
         Pg(i) = P(i);
         SOCb(i) = SOCb(i-1);
         Pbd(i) = 0;
      end
      
    end

    
    
    if ( ((j<(510) && j>(120))) )    % OFF Peak time for charging batteries
        
        Pbd(i)=0;
        
        if SOCb(i-1)<90
        
           Pbc(i)=PbcNom;
           Pg(i) = P(i) + Pbc(i);    %PbcNom defined already
        
           SOCb(i)=SOCb(i-1)+(Pbc(i)*100/(Cb*60));
        else
            
           Pbc(i)=0;
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1); 
           
        end
    end  
end
 
 
if strcmp(day,'Sunday')==1
    
     SOCb(i)=SOCb(i-1);
    
    if ( (j>(1229) && j<(1411)) )    % Peak time
        
        Pbc(i) = 0; % No Charging
        
       if SOCb(i-1) > 25
                    
        if PbdMax > P(i)
            Pbd(i) = P(i);
            Pg(i)= 0;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
       
       
       elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0;

       end
       
    end
    
    
    
    if ( (j<(1230) && j>(1049)) || j<(151) || j>(1410) )    % OFF Peak time
        
        Pbc(i)=0;
                
      if SOCb(i-1) > 25
        
        if P(i) > Peak
            
        if ( PbdMax > ( P(i) - Peak ) )
            Pbd(i) = P(i) - Peak ;
            Pg(i) = Peak;
        else 
            Pbd(i) = PbdMax;
            Pg(i) = P(i) - PbdMax;
        end
        
        SOCb(i)=SOCb(i-1)-(Pbd(i)*100/(Cb*60));
        
        else
          Pg(i) = P(i);
          SOCb(i) = SOCb(i-1); 
        end
       
      elseif SOCb(i-1) < 25
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1);
           Pbd(i) = 0;
    
      end
     
    end
    
    
     if ( ((j<(1050) && j>(150))) )    % OFF Peak time for charging batteries
        
        Pbd(i)=0;
        
        if SOCb(i-1)<90
        
           Pbc(i)=PbcNom;
           Pg(i) = P(i) + Pbc(i);    %PbcNom defined already
        
           SOCb(i)=SOCb(i-1)+(Pbc(i)*100/(Cb*60));
        else
            
           Pbc(i)=0;
           Pg(i) = P(i);
           SOCb(i) = SOCb(i-1); 
           
        end
    end  
end
      
end

%Printing output to excel file
if R==1
Pnew=P';    
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pnew,'MATLAB RESULTS 1','E3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pg,'MATLAB RESULTS 1','F3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbc,'MATLAB RESULTS 1','G3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbd,'MATLAB RESULTS 1','H3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',SOCb,'MATLAB RESULTS 1','I3');
end 

if R==2
Pnew=P';     
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pnew,'MATLAB RESULTS 1','M3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pg,'MATLAB RESULTS 1','N3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbc,'MATLAB RESULTS 1','O3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbd,'MATLAB RESULTS 1','P3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',SOCb,'MATLAB RESULTS 1','Q3');
end 

if R==3
Pnew=P';     
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pnew,'MATLAB RESULTS 1','U3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pg,'MATLAB RESULTS 1','V3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbc,'MATLAB RESULTS 1','W3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbd,'MATLAB RESULTS 1','X3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',SOCb,'MATLAB RESULTS 1','Y3');
end 

if R==4
Pnew=P';    
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pnew,'MATLAB RESULTS 1','AC3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pg,'MATLAB RESULTS 1','AD3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbc,'MATLAB RESULTS 1','AE3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbd,'MATLAB RESULTS 1','AF3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',SOCb,'MATLAB RESULTS 1','AG3');
end 

if R==5
Pnew=P';     
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pnew,'MATLAB RESULTS 1','AK3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pg,'MATLAB RESULTS 1','AL3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbc,'MATLAB RESULTS 1','AM3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbd,'MATLAB RESULTS 1','AN3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',SOCb,'MATLAB RESULTS 1','AO3');
end 

if R==6
Pnew=P';     
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pnew,'MATLAB RESULTS 1','AS3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pg,'MATLAB RESULTS 1','AT3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbc,'MATLAB RESULTS 1','AU3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbd,'MATLAB RESULTS 1','AV3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',SOCb,'MATLAB RESULTS 1','AW3');
end 

if R==7
 Pnew=P';    
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pnew,'MATLAB RESULTS 1','BA3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pg,'MATLAB RESULTS 1','BB3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbc,'MATLAB RESULTS 1','BC3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',Pbd,'MATLAB RESULTS 1','BD3');
xlswrite('H:\Desktop\New Code\kalpesh_matlab\EV HESS Results.xlsx',SOCb,'MATLAB RESULTS 1','BE3');
end 


end
toc